package com.sachin.mapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapperApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.sachin.mapper.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sachin.mapper.model.Location;

public interface LocationRepository extends JpaRepository<Location, Long> {

}

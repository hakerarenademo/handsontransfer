package com.sachin.mapper.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sachin.mapper.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

}

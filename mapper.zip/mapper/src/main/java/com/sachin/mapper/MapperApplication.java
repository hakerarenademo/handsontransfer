package com.sachin.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.sachin.mapper.model.Location;
import com.sachin.mapper.model.User;
import com.sachin.mapper.repository.LocationRepository;
import com.sachin.mapper.repository.UserRepository;


@SpringBootApplication
public class MapperApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(MapperApplication.class, args);
	}

	@Bean
	public ModelMapper modelMapper(){
		return new ModelMapper();
	}

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Override
	public void run(String... args) throws Exception {

		Location location = new Location();
		location.setPlace("Prayagraj");
		location.setDescription("Sangam Nagri");
		location.setLongitude(100.5);
		location.setLatitude(350.6);
		locationRepository.save(location);

		User user1 = new User();
		user1.setFirstName("Sachin");
		user1.setLastName("Sarkar");
		user1.setEmail("Sachin@gmail.com");
		user1.setPassword("pass1");
		user1.setLocation(location);
		userRepository.save(user1);

		User user2 = new User();
		user2.setFirstName("Haker");
		user2.setLastName("Arena");
		user2.setEmail("hak@gmail.com");
		user2.setPassword("pass2");
		user2.setLocation(location);
		userRepository.save(user2);

	}

}
